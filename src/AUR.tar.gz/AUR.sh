

AUR=$(echo AUR)

if [ ! -e ~/AUR ]
then
	mkdir ~/AUR
fi

if [ ! -e ~/AUR/versionActuelle ]
then
	mkdir ~/AUR/versionActuelle
fi

if [ ${1} ]
    then
    #aide
    if [ ${1} = "-h" ]
        then
        echo "[-h] -> aide"
        echo "[-f] -> fonctionememt sans passer par 'AUR'"
        echo "[-n] -> vide le cache"
        echo "[-l] -> liste les paquets installés depuis AUR"
        echo "[-lp] -> liste les paquets non installés depuis pacman"
        echo "[-u] -> liste les paquets pouvant être mis à jour"
        echo "[-ua] -> met à jour les paquets"
        echo "[-v] -> version du programme"
        echo "AUR [option 1] [nom paquet]"
        echo "[-i] -> clonage, création et installation du paquet"
        echo "[-c] -> clonage du paquet"
        echo "[-m] -> créé le paquet (possibilitée d'ajouter les options de makepkg en troisième option"
        echo "[-s] -> fini l'installation avec pacman"
        #fonctionnement
        elif [ ${1} = "-f" ]
            then
            echo "git clone https://aur.archlinux.org/'package'.git"
            echo "dans le dossier clone :" 
            echo "less PKGBUILD"
            echo "makepkg -si"
	#nettoyage
	elif [ ${1} = "-n" ]
	then
	mv ~/AUR/versionActuelle ~/AUR/versionActuelle~
    mv ~/AUR/versionMoinsUn ~/AUR/versionMoinsUn~
    mv ~/AUR/versionMoinsDeux ~/AUR/versionMoinsDeux~          
    declare -a suppression=($(ls -B ~/AUR/))
    for i in ${suppression[@]}
    do
	rm -rdf ~/AUR/$i
	done
	
	
	
	
	
	mv ~/AUR/versionActuelle~ ~/AUR/versionActuelle
    mv ~/AUR/versionMoinsUn~ ~/AUR/versionMoinsUn
    mv ~/AUR/versionMoinsDeux~ ~/AUR/versionMoinsDeux
	
    #version
    elif [ ${1} = "-v" ]
        then
        #version : version publiée|ajout de fonctonalitée|correction de bugs
        echo "version : 1.10.3"
    #liste non pacman
    elif [ ${1} = "-lp" ]
        then
            pacman -Qm
    #liste AUR
    elif [ ${1} = "-l" ]
        then
            declare -a paquets=($(ls ~/AUR/versionActuelle))
            max=${#paquets[@]}
            for i in `seq 1 $max`
                do
                nomPaquet=${paquets[$i-1]}
                nomPaquet=${nomPaquet%%.tar.xz}
		nomPaquet=${nomPaquet%%.tar.zst}
                posVersion=`expr index "$nomPaquet" 0123456789`
                nomPaquet=${nomPaquet:0:$posVersion}
                posVersion=`expr index "$nomPaquet" 0123456789`
                nomPaquet=${nomPaquet:0:$posVersion-2}

                verPaquet=${paquets[$i-1]}
                verPaquet=${verPaquet%%.tar.xz}
		verPaquet=${verPaquet%%.tar.zst}
                posVersion=`expr index "$verPaquet" 0123456789`-1
                verPaquet=${verPaquet:$posVersion}
                posVersion=`expr index "$verPaquet" 0123456789`-1
                verPaquet=${verPaquet:$posVersion}
                
                echo -e "$nomPaquet    $verPaquet"
            done
    #mise à jour
    elif [ ${1} = "-u" ]
        then
        echo "recherche de mises à jour"
		if [ ! -e ~/AUR/.dates ]
			then
			declare -a paquets=($(pacman -Qm))
			touch ~/AUR/.dates
			max=${#paquets[@]}
			let "max = max - 1"
			date=($( date "+%Y-%m-%e"))
			for i in `seq 0 $max`
				do
				test=$(($i%2))
           		 if [ $test -eq 0 ]
        			then
					echo ${paquets[$i]} >> ~/AUR/.dates
					echo $date >> ~/AUR/.dates
				fi
			done
		else
			declare -a paquetsDate=($(cat ~/AUR/.dates))
			maxDates=${#paquetsDate[@]}
			rm ~/AUR/.dates
			for i in `seq 0 $maxDates`
			do
				test=$(($i%2))
				if [ $test -eq 0 ]
				then
					pacman -Q ${paquetsDate[$i]} > /dev/null 2> /dev/null
					testP=($(echo $?))
					if [ $testP -eq 0 ]
					then
						echo ${paquetsDate[$i]} >> ~/AUR/.dates
						echo ${paquetsDate[$(($i+1))]} >> ~/AUR/.dates
					fi
				fi
			done
		fi
	
        declare -a paquets=($(cat ~/AUR/.dates))
        echo "" > ~/AUR/misesajour
        let "pourcent = 0"
        max=${#paquets[@]}
        let "max = max - 1"
		for i in `seq 0 $max`
			do
			test=$(($i%2))
            if [ $test -eq 0 ]
        	then
				datePaquet=`curl --no-progress-meter https://aur.archlinux.org/packages/${paquets[i]} | grep "<td>[0-9][0-9][0-9][0-9]-"`
			let "pourcent = ((i*100)/max)"
			echo $pourcent
			
    
            datePaquet=${datePaquet:36}
            datePaquet=${datePaquet%%[0-9][0-9]:[0-9][0-9]</td>}
			datePaquet=${datePaquet//\-/}
			


            j=$(($i+1))
            verPaquetAct=${paquets[$j]}
       
       	
       		verPaquetAct=${verPaquetAct//\-/}
       		
       
            j=$(($i%2))
    		
            if [ $j -eq 0 ]
                then
                if [ ! -z $datePaquet ]
                    then
                    if [ -n $verPaquetAct ]
                        then
                        if [ $(("$datePaquet" > "$verPaquetAct")) -eq "1" ]
                            then   
							mettreAJour=1

							if [ $mettreAJour = 1 ]
								then
								echo "${paquets[$i]}" >> ~/AUR/misesajour
							fi
                        fi
                    fi
                fi
            fi
            let "i=i+2"
           fi
           
           mettreAJour=0
       done
        cat ~/AUR/misesajour
        
        
        
        
        
    #mise à jour auto
    elif [ ${1} = "-ua" ]
        then
        #AUR -u
        declare -a maj=($(cat ~/AUR/misesajour))
       	declare -a paquets
        max=${#maj[@]}
        let "max = max - 1"
        echo "mettre à jour : "
        for i in `seq 0 $max`
            do
            echo ${maj[$i]}
        done
        
        let "nblimit = 0"
        if [ $max -lt $nblimit ]
            then
            res="n"
        else
            res="non"
        fi
        while [ $res != "o" ] && [ $res != "n" ]
            do
            echo "poursuivre la mise à jour ? [o/n]"
            read
            res=$REPLY
        done
        if [ $res == "o" ]
            then
            #echo "" > ~/AUR/misesajour
            compteur=0
            for i in `seq 0 $max`
                do
                AUR -c ${maj[$i]} &
                compteur=$(($compteur+1))
            done
            if [ $compteur -gt $max ]
                then
                wait
                compteur=0
            fi
            compteur=0
            for i in `seq 0 $max`
                do
                AUR -m ${maj[$i]} &
                compteur=$(($compteur+1))
            done
            if [ $compteur -gt $max ]
                then
                wait
                compteur=0
            fi
            echo "appuyez sur 'entrée' pour continuer"
            read
            paquetsMAJ=""
            for i in `seq 0 $max`
                do
                paquetsMAJ="$paquetMAJ ${maj[$i]}"
                $AUR -s ${maj[$i]} -y
                sed -i -e 's/'${maj[$i]}'//g' ~/AUR/misesajour
            done
            echo $paquetsMAJ
            fi
    #clonage
    elif [ ${1} = "-c" ]
        then
        if [ $2 ]
            then
            if [ -e ~/AUR/${2}/*.tar.xz ]
                then
                echo "un paquet du même nom à déjà été cloné et construit, sans avoir été installé"
            elif [ -e ~/AUR/${2}/PKGBUILD ]
                then
                echo "un paquet du même nom à déjà été cloné, sans avoir été construit"
            else
                git clone https://aur.archlinux.org/${2}.git ~/AUR/${2}
                 if [ -e ~/AUR/${2}/PKGBUILD ]
                    then
                    echo ""
                else
                    echo "aucun paquet cloné"
                    rm -rdf ~/AUR/${2}
                fi
            fi
        else
            echo "veuillez specifier le paquet"
        fi
    #création
    elif [ ${1} = "-m" ]
        then
        if [ ${2} ]
            then
            if [ -e ~/AUR/${2}/*.tar.zst ]
                then
                echo "un paquet à été construit sans avoir été installé"
            elif [ -e ~/AUR/${2}/PKGBUILD ]
                then
                cd ~/AUR/${2}
                makepkg ${3}
                cd -
            else
                echo "aucun paquet cloné"
            fi
        else
            echo "veuillez specifier le paquet"
        fi
    #installation
    elif [ ${1} = "-s" ]
        then
        if [ ${2} ]
            then
            
            if [ -e ~/AUR/${2}/*_orig_*.tar.zst ]
                        then
                        rm ~/AUR/${2}/*_orig_*.tar.zst
                    fi
            if [ ${3} ]
            	then
	            if [ ${3} = "-y" ]
		            then
		            sudo pacman -U --noconfirm ~/AUR/${2}/${2}-*.tar.zst
	            else
		            sudo pacman -U ~/AUR/${2}/${2}-*.tar.zst
	            fi
	            else
		            sudo pacman -U ~/AUR/${2}/${2}-*.tar.zst
	            fi
            if [ $? -eq 0 ]
                then
                if [ ! -e ~/AUR/versionActuelle ]
                    then
                    mkdir ~/AUR/versionActuelle
                fi
               
            #tar.zst
                if [ -e ~/AUR/versionActuelle/${2}-* ]
                    then
                    if [ ! -e ~/AUR/versionMoinsUn ]
                        then
                        mkdir ~/AUR/versionMoinsUn
                    fi
                    if [ -e ~/AUR/versionMoinsUn/${2}-* ]
                        then
                        if [ ! -e ~/AUR/versionMoinsDeux ]
                            then
                            mkdir ~/AUR/versionMoinsDeux
                        fi
                        if [ -e ~/AUR/versionMoinsDeux/${2}-* ]
                        	then
                        	rm  ~/AUR/versionMoinsDeux/${2}-*
                        fi
                    mv ~/AUR/versionMoinsUn/${2}-* ~/AUR/versionMoinsDeux/
                    fi
                mv ~/AUR/versionActuelle/${2}-* ~/AUR/versionMoinsUn/
                fi
            declare -a paquets=($(pacman -Qm ${2}))
            nomFichier=${2}"-"${paquets[1]}
            mv ~/AUR/${2}/${2}-*.tar.zst ~/AUR/versionActuelle/$nomFichier.tar.zst
            rm -rdf ~/AUR/${2}/
            
            
            sed -i '/'${2}'/,+1d' ~/AUR/.dates
            
            echo ${2} >> ~/AUR/.dates
            date=($( date "+%Y-%m-%d"))
	    date=${date/- /-0}
	    date=${date/- /-0}
            echo $date >> ~/AUR/.dates
     
            fi
        else
            echo "veuillez specifier le paquet"
        fi
    #installation complete
    elif [ ${1} = "-i" ]
        then
        if [ ${2} ]
            then
            if [ -e ~/AUR/${2} ]
                then
                echo "un paquet est déja cloné, veuillez finir son installation"
            else
                $AUR -c ${2}
                if [ -e ~/AUR/${2}/PKGBUILD ]
                    then
                    $AUR -m ${2} -s
                    if [ -e ~/AUR/${2}/*_orig_*.tar.xz ]
                        then
                        rm ~/AUR/${2}/*_orig_*.tar.xz
                    fi
                    if [ -e ~/AUR/${2}/*.tar.zst ]
                        then
			echo "continuer ?"
			read
			rep=$REPLY
                        $AUR -s ${2}
                    else
                        echo "aucun paquet construit"
                    fi
                else
                    echo "aucun paquet cloné"
                fi
            fi
        else
            echo "veuillez specifier le paquet"
        fi
    #sinon
    else
        $AUR -h
    fi
else
    $AUR -h
fi
